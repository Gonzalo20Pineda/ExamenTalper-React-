import axios from 'axios'
import {useState, useEffect} from 'react'
import {Link} from 'react-router-dom'

const URI = 'http://localhost:8000/blogs/'


const CompShowBlogs = () => {
    
    const [blogs, setBlog] = useState([])
    useEffect( ()=>{
        getBlogs()
    },[])

    //procedimineto para mostrar todos los blogs
    const getBlogs = async () => {
        const res = await axios.get(URI)
        setBlog(res.data)
    }

    return(
        <div className='container'>
            <div className='row'>
                <div className='col'>  
                <h3>Visualizar Prospectos</h3>    
                <Link to="/" className='btn btn-info'>Volver</Link>         
                    <table className='table'>
                        <thead className='table-primary'>
                            <tr>
                            <th>Nombre</th>
                            <th>Primer apellido</th>
                            <th>Segundo Apellido</th>
                            <th>Estatus</th>
                            <th>Observaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            { blogs.map ( (blog) => (
                                <tr key={ blog.id}>
                                <td> { blog.nombre}</td>
                                <td> { blog.primer_apellido}</td>
                                <td> { blog.segundo_apellido}</td>
                                <td> { blog.estatus}</td>
                                <td> { blog.observaciones}</td>
                                </tr>
                            )) }
                        </tbody>
                    </table>
                </div>    
            </div>
        </div>
    )

}

export default CompShowBlogs