import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {Link} from 'react-router-dom'

const URI = 'http://localhost:8000/blogs/'

const CompEditBlog = () => {
    const [nombre, setNombre] = useState('')
    const [primer_apellido, setPrimer_Apellido] = useState('')
    const [segundo_apellido, setSegundo_Apellido] = useState('')
    const [calle, setCalle] = useState('')
    const [numero, setNumero] = useState('')
    const [colonia, setColonia] = useState('')
    const [codigo_postal, setCodigo_Postal] = useState('')
    const [telefono, setTelefono] = useState('')
    const [rfc, setRfc] = useState('')
    const [estatus, setEstatus] = useState('')  
    const [observaciones, setObservaciones] = useState('')  
    const navigate = useNavigate()
    const {id} = useParams()

    //procedimiento para actualizar
    const update = async (e) => {
        e.preventDefault()
        await axios.put(URI+id, {
            estatus: estatus,
            observaciones: observaciones
        })
        navigate('/Show')
    }

    useEffect( ()=>{
        getBlogById()
    },[])

    const getBlogById = async () => {
        const res = await axios.get(URI+id)
        setNombre(res.data.nombre);
        setPrimer_Apellido(res.data.primer_apellido);
        setSegundo_Apellido(res.data.segundo_apellido);
        setCalle(res.data.calle);
        setNumero(res.data.numero);
        setColonia(res.data.colonia);
        setCodigo_Postal(res.data.codigo_postal);
        setTelefono(res.data.telefono);
        setRfc(res.data.rfc);
        setEstatus(res.data.estatus);
        setObservaciones(res.data.observaciones);
    }

    return (
        <div>
        <h3>Edit POST</h3>
        <Link to="/" className='btn btn-danger'>Cancelar</Link><br></br>
        <form onSubmit={update}>
                <div className="mb-3">
                <label className="form-label">Estatus</label>
                <select
                value={estatus}
                onChange={(e) => setEstatus(e.target.value)}
                className="form-select">
                <option value="Enviado">Enviado</option>
                <option value="Autorizado">Autorizado</option>
                <option value="Rechazado">Rechazado</option>
                </select>
                </div>
                    <div className="mb-3">
                    <label className="form-label">Observaciones</label>
                    <input
                        value={observaciones}
                        onChange={ (e)=> setObservaciones(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>  
                    <div className="mb-3">
                    <label className="form-label">Nombre</label>
                    <input
                        value={nombre}
                        onChange={ (e)=> setNombre(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Primer Apellido</label>
                    <input
                        value={primer_apellido}
                        onChange={ (e)=> setPrimer_Apellido(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Segundo Apellido</label>
                    <input
                        value={segundo_apellido}
                        onChange={ (e)=> setSegundo_Apellido(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Calle</label>
                    <input
                        value={calle}
                        onChange={ (e)=> setCalle(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Numero</label>
                    <input
                        value={numero}
                        onChange={ (e)=> setNumero(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Colonia</label>
                    <input
                        value={colonia}
                        onChange={ (e)=> setColonia(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Codigo Postal</label>
                    <input
                        value={codigo_postal}
                        onChange={ (e)=> setCodigo_Postal(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Telefono</label>
                    <input
                        value={telefono}
                        onChange={ (e)=> setTelefono(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">RFC</label>
                    <input
                        value={rfc}
                        onChange={ (e)=> setRfc(e.target.value)}
                        type="text"
                        className="form-control"
                        disabled  
                    />
                    </div>        
            <button type="submit" className="btn btn-primary">Update</button>
        </form>
    </div>
    )

}

export default CompEditBlog