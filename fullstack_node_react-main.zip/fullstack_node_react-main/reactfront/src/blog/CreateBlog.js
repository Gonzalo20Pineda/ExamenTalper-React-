import axios from 'axios'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {Link} from 'react-router-dom'

const URI = 'http://localhost:8000/blogs/'

const CompCreateBlog = () => {
    const [nombre, setNombre] = useState('')
    const [primer_apellido, setPrimer_Apellido] = useState('')
    const [segundo_apellido, setSegundo_Apellido] = useState('')
    const [calle, setCalle] = useState('')
    const [numero, setNumero] = useState('')
    const [colonia, setColonia] = useState('')
    const [codigo_postal, setCodigo_Postal] = useState('')
    const [telefono, setTelefono] = useState('')
    const [rfc, setRfc] = useState('')
    const [estatus, setEstatus] = useState('Enviado');
    const navigate = useNavigate()  
    
    //procedimiento guardar
    const store = async (e) => {
        e.preventDefault()
        await axios.post(URI, {nombre: nombre, primer_apellido: primer_apellido, segundo_apellido: segundo_apellido, calle: calle, numero: numero, colonia: colonia, codigo_postal: codigo_postal, telefono: telefono, rfc: rfc, estatus: estatus})
        navigate('/')
    }   

    return (
        <div>
            <h3>Create POST</h3>
            <Link to="/" className='btn btn-danger'>Cancelar</Link><br></br>
            <form onSubmit={store}>
                <div className="mb-3">
                    <label className="form-label">Nombre</label>
                    <input
                        value={nombre}
                        onChange={ (e)=> setNombre(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Primer Apellido</label>
                    <input
                        value={primer_apellido}
                        onChange={ (e)=> setPrimer_Apellido(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Segundo Apellido</label>
                    <input
                        value={segundo_apellido}
                        onChange={ (e)=> setSegundo_Apellido(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Calle</label>
                    <input
                        value={calle}
                        onChange={ (e)=> setCalle(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Numero</label>
                    <input
                        value={numero}
                        onChange={ (e)=> setNumero(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Colonia</label>
                    <input
                        value={colonia}
                        onChange={ (e)=> setColonia(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Codigo Postal</label>
                    <input
                        value={codigo_postal}
                        onChange={ (e)=> setCodigo_Postal(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">Telefono</label>
                    <input
                        value={telefono}
                        onChange={ (e)=> setTelefono(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                    <label className="form-label">RFC</label>
                    <input
                        value={rfc}
                        onChange={ (e)=> setRfc(e.target.value)}
                        type="text"
                        className="form-control"
                    />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Estatus</label>
                        <select
                        value={estatus}
                        onChange={(e) => setEstatus(e.target.value)}
                        className="form-select">
                        <option value="Enviado">Enviado</option>
                        </select>
                    </div>

                <button type="submit" className="btn btn-primary">Store</button>
            </form>
        </div>
    )
}

export default CompCreateBlog