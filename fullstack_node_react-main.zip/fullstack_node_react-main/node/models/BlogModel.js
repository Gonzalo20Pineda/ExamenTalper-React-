//importamos la conexión a la DB
import db from "../database/db.js";
//importamos sequelize
import { DataTypes } from "sequelize";

 const BlogModel = db.define('prospectos', {
    nombre: { type: DataTypes.STRING },
    primer_apellido: { type: DataTypes.STRING },
    segundo_apellido: { type: DataTypes.STRING },
    calle: { type: DataTypes.STRING },
    numero: { type: DataTypes.STRING },
    colonia: { type: DataTypes.STRING },
    codigo_postal: { type: DataTypes.STRING },
    telefono: { type: DataTypes.STRING },
    rfc: { type: DataTypes.STRING },
    estatus: { type: DataTypes.STRING },
    observaciones: { type: DataTypes.STRING },
 })

 export default BlogModel