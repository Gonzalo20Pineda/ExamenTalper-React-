import {Sequelize} from 'sequelize'

const db = new Sequelize('examentalper', 'root', '',{
    host:'localhost',
    dialect: 'mysql'
})

export default db